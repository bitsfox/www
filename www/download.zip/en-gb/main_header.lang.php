<?php
$LANG['BaseMainHeaderMyProfile'] = "My Profile";
$LANG['BaseMainHeaderSystemMessages'] = "System Messages";
$LANG['BaseMainHeaderAbout'] = "About";
$LANG['BaseMainHeaderLogout'] = "Logout";
$LANG['BaseMainHeaderLogoutWindowText'] = "Do you really want to Logout?";
$LANG['BaseMainHeaderLogoutWindowWait'] = "Please wait while Logout.";
?>
